# factorial
#roll no: 7198 name=Palak Dhakan
n = int(input("enter the number :"))

fact = 1
for i in range(1, n + 1):
    fact = fact*i
print(f"factorial of {n} is {fact}")
