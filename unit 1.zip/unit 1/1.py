#Write a simple Python Program to INPUT two variables and print 
#Addition, Subtraction, Multiplication and Division of both numbers. 
#roll no: 7198 name=Palak Dhakan
a1 = float(input("enter number 1"))
a2 = float(input("enter number 2"))

print("addition is : ",a1+a2)
print("addition is : ",a1/a2)
print("addition is : ",a1-a2)
print("addition is : ",a1%a2)
print("addition is : ",a1*a2)
