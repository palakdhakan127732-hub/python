# Write a program to input Principal Amount, Rate and Year and 
#display Compound Interest 
#roll no: 7198 name=Palak Dhakan
p = float(input("Enter Principal Amount: "))
r = float(input("Enter Rate of Interest: "))
t = float(input("Enter Time (in years): "))


amount = p * (1 + r / 100) ** t
ci = amount - p


print("Compound Interest =", ci)
