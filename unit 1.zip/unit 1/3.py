# Write a program to input Principal Amount, Rate and Year and 
#display Simple Interest. 
#roll no: 7198 name=Palak Dhakan
p = float(input("Enter Principal Amount: "))
r = float(input("Enter Rate of Interest: "))
t = float(input("Enter Time (in years): "))

si = (p * r * t) / 100

print("Simple Interest =", si)
