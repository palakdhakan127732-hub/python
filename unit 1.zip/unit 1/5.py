# Write a program to input radius of a circle, and print area of that 
#circle.
#roll no: 7198 name=Palak Dhakan
r= float(input("Enter the radius of the circle: "))

area = 3.14 * r * r
print("Area of the circle =", area)
