#Write a program to input age of person and display message as 
#follows - If age < 12 print You are Kid - If age between 12 to 17 print You are teenager - If age between 18 to 60 print you are Adult 
#If age > 60 print You are Senior Citizen
#roll no: 7198 name=Palak Dhakan
age = int(input("Enter your age: "))

if age < 12:
    print("You are Kid")
elif age >= 12 and age <= 17:
    print("You are Teenager")
elif age >= 18  and age <= 60:
    print("You are Adult")
else:
    print("You are Senior Citizen")
