#Write a program to input a number and print whether it is Even or 
#Odd Number. 
#roll no: 7198 name=Palak Dhakan
num=int(input("enter a number for check it even or odd   :"))

if num%2==0:
    print("number is even")
else:
    print("number is odd")
    
