#Write a program to input a number and display Table of that 
#number. 
#roll no: 7198 name=Palak Dhakan
n=int(input("enter a number:"))

for i in range(1,3):
    print(n,"x",i,"=",n*i)
