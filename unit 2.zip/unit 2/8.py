# Write a Python Program to input marks of 4 subjects and display 
#Total, Percentage, Result and Grade. If student is fail (<40) in any 
#subject then Result should be displayed as “FAIL” and Grade should 
#be displayed as “With Held**” 
#roll no: 7198 name=Palak Dhakan
s1 = int(input("Enter marks of Subject 1: "))
s2 = int(input("Enter marks of Subject 2: "))
s3 = int(input("Enter marks of Subject 3: "))
s4 = int(input("Enter marks of Subject 4: "))


total = s1 + s2 + s3 + s4
percentage = total / 4


if s1 < 40 and s2 < 40 and s3 < 40 and s4 < 40:
    result = "FAIL"
    grade = "With Held"
else:
    result = "PASS"
    
    if percentage >= 75:
        grade = "a"
    elif percentage >= 60:
        grade = "b"
    elif percentage >= 50:
        grade = "c"
    else:
        grade = "d"


print("Total Marks:", total)
print("Percentage:", percentage)
print("Result:", result)
print("Grade:", grade)

