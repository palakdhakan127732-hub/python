#Write a program to print all numbers which are divisible by 7 
#between 1 to 200. 
#roll no: 7198 name=Palak Dhakan
for i in range(7,101,7):
    print(i)
